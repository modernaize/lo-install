version=R-v1.8.1
export POSTGRES_VERSION=$version
export UI_VERSION=$version
export SERVICE_VERSION=$version 
export ML_VERSION=$version

docker-compose up -d