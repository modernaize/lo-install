
version=R-2020.2.0
export POSTGRES_VERSION=$version
export UI_VERSION=$version
export SERVICE_VERSION=$version
export ML_VERSION=$version
export LIC_VERSION=$version

export DATA=$HOME/data
export DB_DATA=$DATA/postgres