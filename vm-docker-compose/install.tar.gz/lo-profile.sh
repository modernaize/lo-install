
version=P-v2020.2.0
export POSTGRES_VERSION=P-v2020.2.2
export UI_VERSION=P-v2020.2.6
export SERVICE_VERSION=-P-v2020.2.2
export ML_VERSION=$version
export LIC_VERSION=$version

export DATA=$HOME/data
export DB_DATA=$DATA/postgres