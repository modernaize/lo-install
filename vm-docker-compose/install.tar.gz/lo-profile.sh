export DATA=$HOME/data
export DB_DATA=$DATA/postgres