#

##
in vm-docker-compose 

```
tar -czf install.tar.gz --exclude=install.tar.gz .
```