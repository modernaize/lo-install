# run

docker-compose up -d

## Grafana UI

http://localhost:3000

admin | admin

/grafana/env.grafana

## Prometheus

http://localhost:9090/graph

http://localhost:9090/metrics


## caddy

admin | admin